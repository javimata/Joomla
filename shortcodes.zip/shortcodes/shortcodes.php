<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.shortcodes
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Short codes
 *
 * @since  1.5
 */
class PlgContentShortcodes extends JPlugin
{

	public function onContentPrepare($context, &$row, &$params, $page = 0)
	{
		// Don't run this plugin when the content is being indexed
		// if ($context == 'com_finder.indexer')
		// {
		// 	return true;
		// }

		$row->text = str_replace("[Y]", date('Y'), $row->text);

		/*
		if (is_object($row))
		{
			return $this->_cloak($row->text, $params);
		}

		return $this->_cloak($row, $params);
		*/
	}
}
